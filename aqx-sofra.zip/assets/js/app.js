/* ============================================================
   AQX Food — سفرة اليوم | الملف الرئيسي (رسم الصفحة والتفاعل)
   ============================================================ */

import { CONFIG } from './config.js';
import { getToday, GREG_MONTHS, HIJRI_MONTHS } from './hijri.js';
import { loadPools, loadDetails, minutesOf } from './blogger.js';
import { buildPlans, resolveToday, planLabels, buildMenu } from './planner.js';
import { buildShopping, shoppingToText } from './shopping.js';

/* ---------- أدوات صغيرة ---------- */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
));
const dataUrl = (file) => new URL(`../../data/${file}`, import.meta.url);

async function loadJson(name, fallbackValue) {
  try {
    const res = await fetch(dataUrl(name));
    if (!res.ok) throw new Error(res.status);
    return await res.json();
  } catch (e) {
    return fallbackValue;
  }
}

function toast(msg) {
  const el = $('#toast');
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove('show'), 2400);
}

/* ---------- الحالة ---------- */
const S = {
  conf: null, overrides: {}, fallback: {},
  plans: [], today: null, todayRef: null,
  planId: '', day: 1, token: 0, menu: null, shopping: null
};

const getPlan = (id) => S.plans.find((p) => p.id === id);

function dayLabel(plan, day) {
  return plan.type === 'hijri' ? `${day} رمضان` : `${day} ${plan.name}`;
}

function isTodayView(plan, day) {
  return S.todayRef && S.todayRef.planId === plan.id && S.todayRef.day === day;
}

/* ============================================================
   الواجهة العليا + منتقي الخطة واليوم
   ============================================================ */
function lantern(cls, id) {
  return `
  <svg class="hero__lantern ${cls}" viewBox="0 0 80 170" aria-hidden="true">
    <defs>
      <linearGradient id="gl${id}" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#f7e6a8"/><stop offset=".5" stop-color="#c79a3a"/><stop offset="1" stop-color="#8a6420"/>
      </linearGradient>
      <radialGradient id="gw${id}" cx=".5" cy=".5" r=".6">
        <stop offset="0" stop-color="#fff6c4"/><stop offset="1" stop-color="#f0b84a" stop-opacity=".35"/>
      </radialGradient>
    </defs>
    <line x1="40" y1="0" x2="40" y2="26" stroke="#b98a2e" stroke-width="2"/>
    <path d="M30 26h20l-4 12H34z" fill="url(#gl${id})"/>
    <path d="M26 38h28l8 18v54c0 6-6 10-12 12H30c-6-2-12-6-12-12V56z" fill="url(#gw${id})" stroke="url(#gl${id})" stroke-width="3"/>
    <path d="M40 38v84M26 68h28M23 96h34" stroke="#b98a2e" stroke-width="1.6" fill="none"/>
    <path d="M30 122h20l6 12H24z" fill="url(#gl${id})"/>
    <path d="M40 134v18" stroke="#b98a2e" stroke-width="2"/><circle cx="40" cy="156" r="4" fill="url(#gl${id})"/>
  </svg>`;
}

function renderHero(plan) {
  const g = S.today.greg;
  const h = S.today.hijri;
  const gregText = `${g.day} ${GREG_MONTHS[g.month - 1]} ${g.year}`;
  const hijriText = h ? `${h.day} ${HIJRI_MONTHS[h.month - 1]} ${h.year} هـ` : '';
  const viewing = dayLabel(plan, S.day);
  const todayView = isTodayView(plan, S.day);

  const planOptions = S.plans.map((p) =>
    `<option value="${p.id}" ${p.id === plan.id ? 'selected' : ''}>${p.emoji} ${esc(p.name)}</option>`
  ).join('');

  const days = Array.from({ length: plan.days }, (_, i) => i + 1).map((d) => {
    const cls = ['day', d === S.day ? 'is-active' : '', isTodayView(plan, d) ? 'is-today' : ''].join(' ');
    return `<button class="${cls}" data-day="${d}" aria-label="يوم ${d}" ${d === S.day ? 'aria-current="true"' : ''}>${d}</button>`;
  }).join('');

  $('#hero').innerHTML = `
    ${lantern('l1', 1)}${lantern('l2', 2)}
    <div class="wrap">
      <span class="kicker">✦ AQX FOOD ✦</span>
      <h1 class="hero__title">سفرة اليوم</h1>
      <p class="hero__sub">${plan.emoji} ${esc(plan.theme)}</p>
      <div class="datebadge">
        <span class="pill">📅 ${esc(gregText)}</span>
        ${hijriText ? `<span class="pill">🌙 ${esc(hijriText)}</span>` : ''}
        <span class="pill pill--gold">${todayView ? '✨ سفرة اليوم' : '👁️ تتصفح سفرة'} ${esc(viewing)}</span>
      </div>
      <div class="picker">
        <div class="picker__row">
          <button class="btn-nav" data-nav="1" aria-label="اليوم التالي">›</button>
          <select class="sel" id="planSel" aria-label="اختر الشهر">${planOptions}</select>
          <button class="btn-nav" data-nav="-1" aria-label="اليوم السابق">‹</button>
          ${S.todayRef && !todayView ? '<button class="btn-today" id="goToday">↩ ارجع لليوم</button>' : ''}
        </div>
        <div class="daystrip" id="dayStrip" role="group" aria-label="أيام الخطة">${days}</div>
      </div>
    </div>`;

  const active = $('.day.is-active', $('#hero'));
  if (active) active.scrollIntoView({ block: 'nearest', inline: 'center' });
}

/* ============================================================
   مكونات العرض
   ============================================================ */
function picture(recipe, slot, alt) {
  if (recipe && recipe.image) {
    return `<img src="${esc(recipe.image)}" alt="${esc(alt || recipe.title)}" loading="lazy" data-ph="${esc(slot.icon)}">`;
  }
  return `<div class="ph" aria-hidden="true">${esc(slot.icon)}</div>`;
}

function metaChips(recipe, slot) {
  const m = recipe.meta || {};
  const chips = [];
  if (m.time) chips.push(`⏱️ ${esc(m.time)}`);
  if (m.servings) chips.push(`👨‍👩‍👧‍👦 تكفي ${esc(m.servings)}`);
  if (m.difficulty) chips.push(`⭐ ${esc(m.difficulty)}${/تحضير/.test(m.difficulty) ? '' : ' التحضير'}`);
  if (m.cost) chips.push(`💰 ${esc(m.cost)}`);
  if (slot.mealLabel) chips.push(`🍽️ ${esc(slot.mealLabel)}`);
  return chips.map((c) => `<span class="chip">${c}</span>`).join('');
}

function recipeOfDay(menu) {
  const item = menu.slots.find((s) => s.slot.id === menu.heroId && s.recipe) || menu.slots.find((s) => s.recipe);
  if (!item) {
    return `<div class="panel muted-note">لا توجد وصفات متاحة لهذا اليوم الآن. جرّب يوماً آخر أو زر <a href="${CONFIG.links.home}"><b>الموقع الرئيسي</b></a>.</div>`;
  }
  const { slot, recipe } = item;
  const d = recipe.details || {};
  const ings = d.ingredients || [];
  const steps = d.steps || [];
  const plan = menu.plan;

  const ingHtml = ings.length
    ? `<ul class="ing-list">${ings.map((i) => `<li><span>${esc(i.name)}</span>${i.amount ? `<span>${esc(i.amount)}</span>` : ''}</li>`).join('')}</ul>`
    : `<p class="muted-note">المقادير الكاملة داخل صفحة الوصفة — اضغط «شاهد الوصفة كاملة».</p>`;

  const shown = steps.slice(0, 8);
  const stepHtml = steps.length
    ? `<ol class="step-list">${shown.map((s) => `<li>${esc(s)}</li>`).join('')}</ol>
       ${steps.length > shown.length ? `<p class="muted-note" style="margin-top:12px">… و${steps.length - shown.length} خطوات أخرى في صفحة الوصفة.</p>` : ''}`
    : `<p class="muted-note">خطوات التحضير مفصّلة بالصور داخل صفحة الوصفة.</p>`;

  return `
  <article class="rod reveal">
    <div class="rod__media">
      <span class="rod__badge">🍽️ وصفة اليوم</span>
      ${picture(recipe, slot, recipe.title)}
    </div>
    <div class="rod__body">
      <div class="rod__kicker">✦ وصفة مختارة ليوم ${esc(dayLabel(plan, menu.day))}</div>
      <h2 class="rod__title">${esc(recipe.title)}</h2>
      ${recipe.description ? `<p class="rod__desc">${esc(recipe.description)}</p>` : ''}
      <div class="chips">${metaChips(recipe, slot)}</div>
      <div class="rod__cta">
        <a class="btn btn--gold" href="${esc(recipe.url)}" target="_blank" rel="noopener">شاهد الوصفة كاملة ←</a>
        <button class="btn btn--ghost" data-scroll="#plan">🛒 قائمة التسوق</button>
      </div>
    </div>
  </article>
  <div class="rod-details">
    <div class="panel reveal"><h3>🧺 المكونات</h3>${ingHtml}</div>
    <div class="panel reveal"><h3>👩‍🍳 طريقة التحضير</h3>${stepHtml}</div>
  </div>`;
}

function sofraGrid(menu) {
  return `<div class="sofra-grid">${menu.slots.map((item, i) => {
    const { slot, recipe } = item;
    if (!recipe) {
      return `<div class="dish dish--empty reveal">
        <div style="font-size:2.6rem">${esc(slot.icon)}</div>
        <b>${esc(slot.title)}</b>
        <small>سيظهر هنا فور إضافة وصفة بقسم «${esc(slot.labels[0])}»</small>
      </div>`;
    }
    const m = recipe.meta || {};
    const isHero = slot.id === menu.heroId;
    return `<article class="dish reveal" style="transition-delay:${Math.min(i, 5) * 70}ms">
      <div class="dish__media">
        ${picture(recipe, slot)}
        <span class="dish__num">${i + 1}</span>
        <span class="dish__course">${esc(slot.icon)} ${esc(slot.title)}</span>
      </div>
      <div class="dish__body">
        <h3 class="dish__title">${esc(recipe.title)}</h3>
        ${recipe.description ? `<p class="dish__desc">${esc(recipe.description)}</p>` : ''}
        <div class="dish__meta">
          ${isHero ? '<span class="tag">⭐ وصفة اليوم</span>' : ''}
          ${m.time ? `<span class="tag">⏱️ ${esc(m.time)}</span>` : ''}
          ${slot.mealLabel ? `<span class="tag">${esc(slot.mealLabel)}</span>` : ''}
        </div>
        <a class="dish__link" href="${esc(recipe.url)}" target="_blank" rel="noopener">شاهد الوصفة كاملة ←</a>
      </div>
    </article>`;
  }).join('')}</div>`;
}

function timelineHtml(menu) {
  const items = menu.slots.filter((s) => s.recipe);
  if (!items.length) return '<p class="muted-note">لا توجد أطباق لعرض خطة التحضير.</p>';
  return `<div class="timeline">${items.map(({ slot, recipe }, i) => {
    const mins = minutesOf(recipe.meta && recipe.meta.time);
    return `<div class="tl reveal">
      <div class="tl__dot" aria-hidden="true">${esc(slot.icon)}</div>
      <div class="tl__body">
        <span class="tl__min">الخطوة ${i + 1}${mins ? ` · ⏱️ حوالي ${mins} دقيقة` : ''}</span>
        <div><b>${esc(slot.step || 'جهّز ' + slot.title)}</b></div>
        <small>${esc(recipe.title)}</small>
      </div>
    </div>`;
  }).join('')}</div>`;
}

/* ============================================================
   قائمة التسوق
   ============================================================ */
const shopKey = (menu) => `aqx:shop:${menu.plan.id}:${menu.day}`;

function loadShopState(menu) {
  try {
    const raw = localStorage.getItem(shopKey(menu));
    if (raw) return JSON.parse(raw);
  } catch (e) { /* تجاهل */ }
  return { added: false, checked: {}, custom: [] };
}

function saveShopState(menu, state) {
  try { localStorage.setItem(shopKey(menu), JSON.stringify(state)); } catch (e) { /* تجاهل */ }
}

function shopHtml(menu, shopping, state) {
  const dishesCount = menu.slots.filter((s) => s.recipe).length;

  if (!state.added) {
    return `<div class="panel shop" id="shopping">
      <h3>🛒 قائمة التسوق</h3>
      <p class="muted-note">نجمع لك مقادير ${dishesCount} أطباق في قائمة واحدة مرتبة حسب أقسام السوق، وتقدر تعلّم عليها وأنت بتشتري.</p>
      ${shopping.total
        ? `<button class="btn btn--gold" data-act="add-list" style="margin-top:14px">🛒 أضف مكونات سفرة اليوم إلى قائمة التسوق (${shopping.total})</button>`
        : '<p class="shop__empty">لم نتمكن من قراءة المقادير تلقائياً لهذا اليوم. افتح الوصفات من السفرة لمعرفة مكوناتها.</p>'}
    </div>`;
  }

  const groups = shopping.groups.map((g) => `
    <div class="shop__group">
      <h4>${g.icon} ${esc(g.name)}</h4>
      ${g.items.map((it) => `
        <label class="shop__item ${state.checked[it.key] ? 'is-done' : ''}">
          <input type="checkbox" data-key="${esc(it.key)}" ${state.checked[it.key] ? 'checked' : ''}>
          <span>${esc(it.name)}</span>
          ${it.amount ? `<em>${esc(it.amount)}</em>` : ''}
        </label>`).join('')}
    </div>`).join('');

  const custom = state.custom.length ? `
    <div class="shop__group">
      <h4>✍️ إضافاتي</h4>
      ${state.custom.map((c) => `
        <label class="shop__item ${state.checked['c:' + c] ? 'is-done' : ''}">
          <input type="checkbox" data-key="${esc('c:' + c)}" ${state.checked['c:' + c] ? 'checked' : ''}>
          <span>${esc(c)}</span>
          <button type="button" class="btn-today" data-act="del-custom" data-item="${esc(c)}" aria-label="حذف">✕</button>
        </label>`).join('')}
    </div>` : '';

  const missing = shopping.missing.length
    ? `<p class="muted-note" style="margin-top:12px">تعذّر قراءة مقادير: ${shopping.missing.map(esc).join('، ')} — افتح وصفتها وأضف مكوناتها يدوياً.</p>` : '';

  return `<div class="panel shop" id="shopping">
    <div class="shop__head">
      <h3 style="margin:0">🛒 قائمة تسوق ${esc(dayLabel(menu.plan, menu.day))}</h3>
      <div class="shop__actions">
        <button class="btn btn--ghost btn--sm" data-act="copy">📋 نسخ</button>
        <button class="btn btn--ghost btn--sm" data-act="whatsapp">💬 واتساب</button>
        <button class="btn btn--ghost btn--sm" data-act="print">🖨️ طباعة</button>
        <button class="btn btn--ghost btn--sm" data-act="reset">↺ مسح التعليم</button>
      </div>
    </div>
    <div class="muted-note" id="shopCount"></div>
    <div class="progress"><i id="shopBar"></i></div>
    ${groups}${custom}${missing}
    <form class="shop__add" id="shopForm">
      <input type="text" id="shopInput" placeholder="أضف شيئاً آخر للقائمة…" maxlength="60" aria-label="إضافة عنصر">
      <button class="btn btn--gold btn--sm" type="submit">＋ أضف</button>
    </form>
  </div>`;
}

function updateShopProgress(menu, state) {
  const bar = $('#shopBar');
  const count = $('#shopCount');
  if (!bar || !count) return;
  const total = S.shopping.total + state.custom.length;
  const done = Object.values(state.checked).filter(Boolean).length;
  const pct = total ? Math.round((done / total) * 100) : 0;
  bar.style.width = pct + '%';
  count.textContent = `تم شراء ${done} من ${total} (${pct}%)`;
}

function bindShopping(menu) {
  const box = $('#shopping');
  if (!box) return;
  let state = loadShopState(menu);

  const rerender = () => {
    box.outerHTML = shopHtml(menu, S.shopping, state);
    bindShopping(menu);
  };

  box.addEventListener('click', async (e) => {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    const act = btn.dataset.act;
    const heading = `🛒 قائمة تسوق سفرة اليوم — ${dayLabel(menu.plan, menu.day)}`;
    const text = () => shoppingToText(S.shopping, state.checked, state.custom, heading);

    if (act === 'add-list') {
      state.added = true; saveShopState(menu, state); rerender();
      toast(`تمت إضافة ${S.shopping.total} مكوّن إلى قائمتك ✓`);
    } else if (act === 'copy') {
      try { await navigator.clipboard.writeText(text()); }
      catch (err) {
        const ta = document.createElement('textarea'); ta.value = text(); document.body.appendChild(ta); ta.select();
        document.execCommand('copy'); ta.remove();
      }
      toast('تم نسخ القائمة 📋');
    } else if (act === 'whatsapp') {
      window.open(`https://wa.me/?text=${encodeURIComponent(text())}`, '_blank', 'noopener');
    } else if (act === 'print') {
      document.body.classList.add('print-shop');
      window.addEventListener('afterprint', () => document.body.classList.remove('print-shop'), { once: true });
      window.print();
    } else if (act === 'reset') {
      state.checked = {}; saveShopState(menu, state); rerender();
    } else if (act === 'del-custom') {
      e.preventDefault();
      const item = btn.dataset.item;
      state.custom = state.custom.filter((c) => c !== item);
      delete state.checked['c:' + item];
      saveShopState(menu, state); rerender();
    }
  });

  box.addEventListener('change', (e) => {
    const input = e.target.closest('input[type=checkbox][data-key]');
    if (!input) return;
    state.checked[input.dataset.key] = input.checked;
    if (!input.checked) delete state.checked[input.dataset.key];
    input.closest('.shop__item').classList.toggle('is-done', input.checked);
    saveShopState(menu, state);
    updateShopProgress(menu, state);
  });

  box.addEventListener('submit', (e) => {
    if (e.target.id !== 'shopForm') return;
    e.preventDefault();
    const input = $('#shopInput');
    const value = input.value.trim();
    if (!value || state.custom.includes(value)) return;
    state.custom.push(value);
    saveShopState(menu, state); rerender();
  });

  updateShopProgress(menu, state);
}

/* ============================================================
   رسم المحتوى الكامل
   ============================================================ */
function exploreHtml() {
  return `<div class="explore-grid">${CONFIG.explore.map((c) =>
    `<a class="explore-chip reveal" href="${CONFIG.links.label(c.name)}" target="_blank" rel="noopener"><i>${c.icon}</i>${esc(c.name)}</a>`
  ).join('')}</div>`;
}

function renderContent(menu, offline) {
  S.shopping = buildShopping(menu);
  const plan = menu.plan;

  $('#content').innerHTML = `
    ${offline ? `<div class="wrap"><div class="panel muted-note" style="margin-bottom:10px">⚠️ تعذّر الاتصال بأقسام الموقع الآن، نعرض اقتراحات احتياطية. حدّث الصفحة لاحقاً.</div></div>` : ''}

    <section class="sec" id="today"><div class="wrap">
      <div class="sec__head reveal">
        <div class="sec__eyebrow">✦ اختيارنا لك ✦</div>
        <h2 class="sec__title">وصفة اليوم</h2>
        <div class="sec__ornament">❖</div>
      </div>
      ${recipeOfDay(menu)}
    </div></section>

    <section class="sec" id="sofra"><div class="wrap">
      <div class="sec__head reveal">
        <div class="sec__eyebrow">✦ مائدة متكاملة ✦</div>
        <h2 class="sec__title">سفرة ${esc(dayLabel(plan, menu.day))}</h2>
        <div class="sec__ornament">❖</div>
        <p class="sec__note">أطباق متناسقة من أقسام الموقع، تتجدد تلقائياً كل يوم.</p>
      </div>
      ${sofraGrid(menu)}
    </div></section>

    <section class="sec" id="plan"><div class="wrap">
      <div class="sec__head reveal">
        <div class="sec__eyebrow">✦ مساعد المطبخ ✦</div>
        <h2 class="sec__title">خطة التحضير وقائمة التسوق</h2>
        <div class="sec__ornament">❖</div>
      </div>
      <div class="twocol">
        <div class="timeline-col">
          <div class="panel"><h3>⏱️ خطة التحضير</h3>${timelineHtml(menu)}</div>
        </div>
        <div>${shopHtml(menu, S.shopping, loadShopState(menu))}</div>
      </div>
    </div></section>

    <section class="sec" id="explore"><div class="wrap">
      <div class="sec__head reveal">
        <div class="sec__eyebrow">✦ واصل التصفح ✦</div>
        <h2 class="sec__title">أقسام مطبخ القرماني إكس</h2>
        <div class="sec__ornament">❖</div>
      </div>
      ${exploreHtml()}
    </div></section>`;

  bindShopping(menu);
  bindImages();
  observeReveal();
}

function bindImages() {
  $$('img[data-ph]').forEach((img) => {
    img.addEventListener('error', () => {
      const ph = document.createElement('div');
      ph.className = 'ph';
      ph.textContent = img.dataset.ph;
      img.replaceWith(ph);
    }, { once: true });
  });
}

function observeReveal() {
  const els = $$('.reveal:not(.in)');
  if (!('IntersectionObserver' in window)) { els.forEach((el) => el.classList.add('in')); return; }
  const io = new IntersectionObserver((entries) => {
    entries.forEach((en) => {
      if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
    });
  }, { threshold: 0.12 });
  els.forEach((el) => io.observe(el));
}

/* ============================================================
   التحميل والتنقل
   ============================================================ */
function syncUrl() {
  const q = new URLSearchParams(location.search);
  q.set('plan', S.planId);
  q.set('day', S.day);
  history.replaceState(null, '', `${location.pathname}?${q.toString()}${location.hash}`);
}

async function refresh() {
  const token = ++S.token;
  const plan = getPlan(S.planId);
  syncUrl();
  renderHero(plan);
  $('#content').innerHTML = `<div class="wrap" style="padding-top:40px"><div class="skel"></div></div>`;

  const pools = await loadPools(planLabels(plan));
  if (token !== S.token) return;

  const offline = Object.values(pools).every((list) => !list.length);
  const menu = buildMenu(plan, S.day, pools, S.overrides, S.fallback, S.conf.globalExclude || []);
  S.menu = menu;

  await Promise.all(menu.slots.filter((s) => s.recipe).map((s) => loadDetails(s.recipe)));
  if (token !== S.token) return;

  renderContent(menu, offline);
  if (location.hash) {
    const target = $(location.hash);
    if (target) target.scrollIntoView();
  }
}

function go(planId, day) {
  const plan = getPlan(planId);
  if (!plan) return;
  S.planId = plan.id;
  S.day = Math.min(Math.max(1, day), plan.days);
  refresh();
}

function bindGlobal() {
  const hero = $('#hero');

  hero.addEventListener('click', (e) => {
    const dayBtn = e.target.closest('[data-day]');
    if (dayBtn) return go(S.planId, parseInt(dayBtn.dataset.day, 10));

    const nav = e.target.closest('[data-nav]');
    if (nav) {
      const plan = getPlan(S.planId);
      let next = S.day + parseInt(nav.dataset.nav, 10);
      if (next < 1) next = plan.days;
      if (next > plan.days) next = 1;
      return go(S.planId, next);
    }
    if (e.target.closest('#goToday')) go(S.todayRef.planId, S.todayRef.day);
  });

  hero.addEventListener('change', (e) => {
    if (e.target.id !== 'planSel') return;
    const plan = getPlan(e.target.value);
    const keepToday = S.todayRef.planId === plan.id ? S.todayRef.day : 1;
    go(plan.id, keepToday);
  });

  document.addEventListener('click', (e) => {
    const sc = e.target.closest('[data-scroll]');
    if (!sc) return;
    const target = $(sc.dataset.scroll);
    if (target) target.scrollIntoView({ behavior: 'smooth' });
  });
}

async function init() {
  const app = $('#app');
  const [conf, overrides, fallback] = await Promise.all([
    loadJson('months.json', null),
    loadJson('overrides.json', {}),
    loadJson('fallback.json', {})
  ]);

  if (!conf) {
    app.innerHTML = `<div class="wrap" style="padding:60px 0;text-align:center">
      تعذّر تحميل ملفات الإعدادات. إذا فتحت الملف مباشرة من الجهاز استخدم خادماً محلياً أو انشره على GitHub Pages.<br>
      <a class="btn btn--gold" style="margin-top:16px" href="${CONFIG.links.home}">الموقع الرئيسي</a></div>`;
    return;
  }

  S.conf = conf; S.overrides = overrides; S.fallback = fallback;
  S.today = getToday(new Date(), CONFIG);
  S.plans = buildPlans(conf, S.today.greg.year);
  S.todayRef = resolveToday(S.today, S.plans, CONFIG.ramadanHijriMonth);

  const q = new URLSearchParams(location.search);
  const plan = getPlan(q.get('plan')) || getPlan(S.todayRef.planId);
  let day = parseInt(q.get('day'), 10);
  if (!(day >= 1 && day <= plan.days)) day = plan.id === S.todayRef.planId ? S.todayRef.day : 1;

  S.planId = plan.id;
  S.day = Math.min(day, plan.days);

  app.innerHTML = `<section class="hero" id="hero"></section><div id="content"></div>`;
  bindGlobal();
  await refresh();
}

init();
