/* ============================================================
   سحب الوصفات من بلوجر (Feeds JSON) بالاسم الفعلي للقسم (Label)
   - قوائم الأقسام: خفيفة وتتخزن في المتصفح
   - تفاصيل الوصفة (المقادير/الخطوات): تُسحب فقط لوصفات سفرة اليوم
   ============================================================ */

import { CONFIG } from './config.js';
import { toLatinDigits } from './hijri.js';

/* ---------- تخزين مؤقت آمن ---------- */
function cacheGet(key, maxHours) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const obj = JSON.parse(raw);
    return { data: obj.d, fresh: Date.now() - obj.t < maxHours * 3600000 };
  } catch (e) {
    return null;
  }
}

function cacheSet(key, data) {
  try {
    localStorage.setItem(key, JSON.stringify({ t: Date.now(), d: data }));
  } catch (e) { /* التخزين ممتلئ أو غير متاح */ }
}

async function getJson(url, timeoutMs = 15000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { signal: ctrl.signal });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } finally {
    clearTimeout(timer);
  }
}

/* ---------- أدوات نصوص ---------- */
const ENTITIES = { '&nbsp;': ' ', '&amp;': '&', '&quot;': '"', '&#39;': "'", '&lt;': '<', '&gt;': '>' };

export function htmlToText(html) {
  return String(html || '')
    .replace(/<(script|style)[\s\S]*?<\/\1>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<br\s*\/?>|<\/(p|div|li|h[1-6]|tr)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&(nbsp|amp|quot|lt|gt|#39);/g, (m) => ENTITIES[m] || ' ')
    .replace(/[ \t ]+/g, ' ')
    .replace(/\n\s*\n+/g, '\n')
    .trim();
}

/** رفع جودة صور بلوجر */
export function bigImage(url, size = 1200) {
  if (!url) return '';
  return url
    .replace(/\/s\d+(-c)?\//, `/s${size}/`)
    .replace(/\/w\d+-h\d+(-c)?\//, `/s${size}/`)
    .replace(/=s\d+(-c)?$/, `=s${size}`);
}

/* ---------- استخراج بيانات الوقت والأفراد ... إلخ ---------- */
export function extractMeta(text) {
  const t = toLatinDigits(text || '');
  const meta = {};
  let m;

  m = t.match(/(?:وقت\s*(?:الطهي|الطهى|التحضير|التجهيز)[^\n:：]{0,20}|مدة\s*(?:التحضير|الطهي)|الوقت)\s*[:：]?\s*\n?\s*(\d+(?:\s*[-–]\s*\d+)?\s*(?:دقيقة|دقائق|د|ساعة|ساعات))/);
  if (m) meta.time = m[1].replace(/\s+/g, ' ').trim();

  m = t.match(/(?:تكفي|يكفي|عدد\s*(?:الأفراد|الحصص|الأشخاص)|الحصص|الكمية\s*والمقدار)\s*(?:لـ)?\s*[:：]?\s*\n?\s*(?:تكفي|يكفي)?\s*(\d+(?:\s*[-–]\s*\d+)?)\s*(أشخاص|اشخاص|أفراد|افراد|شخص|فرد|حصص|حصة)?/);
  if (m) meta.servings = `${m[1].replace(/\s+/g, '')} ${m[2] || 'أفراد'}`.replace('اشخاص', 'أشخاص');

  m = t.match(/(?:المستوى|الصعوبة|مستوى\s*الصعوبة)\s*[:：]?\s*\n?\s*(سهل\S*|متوسط\S*|صعب\S*)/);
  if (m) meta.difficulty = m[1];

  m = t.match(/(?:التكلفة(?:\s*التقريبية)?|السعر(?:\s*التقريبي)?)\s*[:：]?\s*\n?\s*([^\n|•]{2,28})/);
  if (m) meta.cost = m[1].trim();

  return meta;
}

/** تحويل نص الوقت إلى دقائق (للخطة) */
export function minutesOf(timeText) {
  if (!timeText) return null;
  const t = toLatinDigits(timeText);
  if (!/\d/.test(t)) return /ساعة/.test(t) ? 60 : null;
  const m = t.match(/(\d+)(?:\s*[-–]\s*(\d+))?\s*(ساعة|ساعات)?/);
  if (!m) return null;
  const n = m[2] ? Math.round((+m[1] + +m[2]) / 2) : +m[1];
  return m[3] ? n * 60 : n;
}

/* ---------- تحويل مدخلة الفيد إلى وصفة خفيفة ---------- */
function normalizeEntry(e) {
  const links = e.link || [];
  const alt = links.find((l) => l.rel === 'alternate');
  const html = (e.content && e.content.$t) || (e.summary && e.summary.$t) || '';
  const text = htmlToText(html);

  let image = e['media$thumbnail'] ? e['media$thumbnail'].url : '';
  const firstImg = html.match(/<img[^>]+src=["']([^"']+)["']/i);
  if (firstImg) image = firstImg[1];

  const idMatch = (e.id && e.id.$t || '').match(/post-(\d+)/);

  // وصف قصير: أول فقرة نصية جيدة الطول
  const lines = text.split('\n').map((s) => s.trim()).filter((s) => s.length > 50);
  let desc = (lines[0] || '').replace(/\s*\.\.\.\s*/g, ' — ');
  if (desc.length > 190) desc = desc.slice(0, 187).replace(/\s+\S*$/, '') + '…';

  return {
    postId: idMatch ? idMatch[1] : '',
    title: (e.title && e.title.$t) || '',
    url: alt ? alt.href : '',
    published: (e.published && e.published.$t) || '',
    labels: (e.category || []).map((c) => c.term),
    image: bigImage(image),
    description: desc,
    meta: extractMeta(text)
  };
}

/* ---------- قائمة وصفات قسم كامل ---------- */
export async function fetchLabel(label) {
  const key = `aqx:label:${label}`;
  const cached = cacheGet(key, CONFIG.cacheHours);
  if (cached && cached.fresh) return cached.data;

  const url = `${CONFIG.blogUrl}/feeds/posts/default/-/${encodeURIComponent(label)}?alt=json&max-results=${CONFIG.maxResults}`;
  try {
    const json = await getJson(url);
    const entries = ((json.feed && json.feed.entry) || []).map(normalizeEntry).filter((r) => r.url);
    cacheSet(key, entries);
    return entries;
  } catch (err) {
    return cached ? cached.data : [];
  }
}

/** يرجع { اسم القسم: [وصفات] } لكل الأقسام المطلوبة */
export async function loadPools(labels) {
  const unique = [...new Set(labels)];
  const results = await Promise.all(unique.map((l) => fetchLabel(l)));
  const pools = {};
  unique.forEach((l, i) => { pools[l] = results[i]; });
  return pools;
}

/* ---------- تفاصيل وصفة واحدة (مقادير + خطوات) ---------- */
function parseDetails(html) {
  const doc = new DOMParser().parseFromString(html || '', 'text/html');
  doc.querySelectorAll('script,style,ins,noscript').forEach((n) => n.remove());

  const txt = (n) => (n ? n.textContent.replace(/\s+/g, ' ').trim() : '');
  const ingredients = [];
  const steps = [];

  /* 1) قالب AQX المنسّق (الكروت) */
  doc.querySelectorAll('.aqx-ing-card, .aqx-ingredient-card').forEach((card) => {
    const name = txt(card.querySelector('.aqx-ing-title, .aqx-ing-name'));
    const amount = txt(card.querySelector('.aqx-ing-amount'));
    const cleanName = name.replace(/^[^\p{L}\p{N}]+/u, '').trim();
    if (cleanName) ingredients.push({ name: cleanName, amount });
  });
  doc.querySelectorAll('.aqx-step-text').forEach((n) => {
    const s = txt(n).replace(/^[^\p{L}\p{N}]+/u, '').trim();
    if (s) steps.push(s);
  });

  /* 2) احتياطي: عناوين «المقادير» و«طريقة التحضير» مع قوائم */
  if (!ingredients.length || !steps.length) {
    const blocks = [...doc.body.querySelectorAll('h1,h2,h3,h4,h5,h6,p,li,div')]
      .filter((n) => !(n.tagName === 'DIV' && n.querySelector('div,p,li,h1,h2,h3,h4')))
      .filter((n) => !(n.tagName === 'P' && n.closest('li')));
    let mode = '';
    const ingFallback = [];
    const stepFallback = [];
    for (const n of blocks) {
      const t = txt(n);
      if (!t) continue;
      const isHead = /^H[1-6]$/.test(n.tagName) || (t.length < 55 && n.querySelector('strong,b'));
      if (isHead) {
        if (/(المقادير|المكونات|مكونات)/.test(t)) { mode = 'ing'; continue; }
        if (/(طريقة\s*(التحضير|العمل|التنفيذ)|خطوات)/.test(t)) { mode = 'steps'; continue; }
        if (mode) mode = '';
        continue;
      }
      if (mode === 'ing' && n.tagName === 'LI') ingFallback.push({ name: t, amount: '' });
      if (mode === 'steps' && (n.tagName === 'LI' || n.tagName === 'P')) stepFallback.push(t);
    }
    if (!ingredients.length) ingredients.push(...ingFallback);
    if (!steps.length) steps.push(...stepFallback);
  }

  /* 3) كروت الوقت/الأفراد في القالب */
  const meta = extractMeta(txt(doc.body) ? doc.body.innerText || '' : '');
  const metaCards = [...doc.querySelectorAll('.aqx-meta-card, .aqx-meta-item')];
  const merged = {};
  metaCards.forEach((card) => {
    const label = txt(card.querySelector('.aqx-meta-label'));
    const value = txt(card.querySelector('.aqx-meta-value, .aqx-meta-val'));
    if (!value) return;
    if (/(وقت|مدة)/.test(label)) merged.time = toLatinDigits(value);
    else if (/(يكفي|تكفي|الكمية|الأفراد|الحصص)/.test(label)) {
      const m = toLatinDigits(value).match(/(\d+(?:\s*[-–]\s*\d+)?)\s*(\S+)?/);
      if (m) merged.servings = `${m[1].replace(/\s+/g, '')} ${(m[2] || 'أفراد').replace('اشخاص', 'أشخاص')}`;
    } else if (/(المستوى|الصعوبة)/.test(label)) merged.difficulty = value;
    else if (/(التكلفة|السعر)/.test(label)) merged.cost = value;
  });

  return { ingredients, steps, meta: { ...meta, ...merged } };
}

async function fetchEntryHtml(recipe) {
  const tries = [];
  if (recipe.postId) tries.push(`${CONFIG.blogUrl}/feeds/posts/default/${recipe.postId}?alt=json`);
  try {
    const path = new URL(recipe.url).pathname;
    tries.push(`${CONFIG.blogUrl}/feeds/posts/default?alt=json&path=${encodeURIComponent(path)}`);
  } catch (e) { /* رابط غير صالح */ }

  for (const u of tries) {
    try {
      const json = await getJson(u);
      const entry = json.entry || (json.feed && json.feed.entry && json.feed.entry[0]);
      if (entry && entry.content) return entry.content.$t;
    } catch (e) { /* جرّب الطريقة التالية */ }
  }
  return '';
}

export async function loadDetails(recipe) {
  if (!recipe || !recipe.url) return recipe;
  const key = `aqx:post:${recipe.postId || recipe.url}`;
  const cached = cacheGet(key, CONFIG.detailCacheHours);
  if (cached && cached.fresh) {
    recipe.details = cached.data;
  } else {
    const html = await fetchEntryHtml(recipe);
    if (html) {
      recipe.details = parseDetails(html);
      cacheSet(key, recipe.details);
    } else if (cached) {
      recipe.details = cached.data;
    }
  }
  if (recipe.details && recipe.details.meta) {
    recipe.meta = { ...recipe.details.meta, ...recipe.meta, ...recipe.details.meta };
  }
  return recipe;
}
