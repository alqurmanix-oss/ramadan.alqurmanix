/* ============================================================
   AQX Food — إعدادات صفحة «سفرة اليوم»
   عدّل هنا فقط: رابط المدونة، مدة التخزين المؤقت، الأقسام المقترحة
   ============================================================ */

export const CONFIG = {
  // رابط مدونة بلوجر (بدون / في الآخر)
  blogUrl: 'https://aqxfood.blogspot.com',

  // أقصى عدد وصفات يتم سحبها من كل قسم
  maxResults: 150,

  // مدة تخزين قوائم الأقسام في المتصفح (بالساعات)
  cacheHours: 6,

  // مدة تخزين تفاصيل الوصفة (المقادير والخطوات) بالساعات
  detailCacheHours: 48,

  // المنطقة الزمنية لحساب «اليوم»
  timeZone: 'Africa/Cairo',

  // لو رؤية الهلال تختلف عن التقويم المعتمد: +1 أو -1 يوم
  hijriOffsetDays: 0,

  // رقم شهر رمضان في التقويم الهجري
  ramadanHijriMonth: 9,

  links: {
    home: 'https://aqxfood.blogspot.com/',
    mealPlanner: 'https://aqxfood.blogspot.com/2026/09/blog-post.html',
    label: (name) => `https://aqxfood.blogspot.com/search/label/${encodeURIComponent(name)}`
  },

  // أقسام «واصل التصفح» أسفل الصفحة (بأسماء الأقسام في بلوجر)
  explore: [
    { name: 'أطباق الفطور', icon: '☀️' },
    { name: 'وصفات غداء', icon: '🍽️' },
    { name: 'عشاء', icon: '🌙' },
    { name: 'عزومات ومناسبات', icon: '👨‍👩‍👧‍👦' },
    { name: 'سلطات', icon: '🥗' },
    { name: 'شوربات', icon: '🍲' },
    { name: 'مقبلات', icon: '🥟' },
    { name: 'حلويات', icon: '🍰' },
    { name: 'المطبخ المصري', icon: '🇪🇬' },
    { name: 'المطبخ السعودي', icon: '🇸🇦' },
    { name: 'وصفات للريجيم', icon: '🥦' },
    { name: 'وصفات الأعضاء', icon: '👨‍🍳' }
  ]
};
