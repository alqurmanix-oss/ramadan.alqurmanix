/* ============================================================
   التاريخ: الميلادي والهجري (بدون أي مكتبات خارجية)
   ============================================================ */

export const GREG_MONTHS = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
];

export const HIJRI_MONTHS = [
  'محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة',
  'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'
];

const AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';

export function toArabicDigits(value) {
  return String(value).replace(/\d/g, (d) => AR_DIGITS[d]);
}

export function toLatinDigits(value) {
  return String(value)
    .replace(/[٠-٩]/g, (d) => String(AR_DIGITS.indexOf(d)))
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
}

function partsOf(date, locale, timeZone) {
  const fmt = new Intl.DateTimeFormat(locale, {
    day: 'numeric', month: 'numeric', year: 'numeric', timeZone
  });
  const out = {};
  for (const p of fmt.formatToParts(date)) {
    if (p.type === 'day' || p.type === 'month' || p.type === 'year') out[p.type] = parseInt(p.value, 10);
  }
  return out;
}

export function getGregorian(date, timeZone) {
  return partsOf(date, 'en-US-u-nu-latn', timeZone);
}

export function getHijri(date, timeZone, offsetDays = 0) {
  const shifted = new Date(date.getTime() + offsetDays * 86400000);
  try {
    return partsOf(shifted, 'en-u-ca-islamic-umalqura-nu-latn', timeZone);
  } catch (e) {
    return null;
  }
}

export function daysInGregorianMonth(year, month) {
  return new Date(year, month, 0).getDate();
}

/** يرجع كائناً فيه تاريخ اليوم بالميلادي والهجري */
export function getToday(now, { timeZone, hijriOffsetDays }) {
  const g = getGregorian(now, timeZone);
  const h = getHijri(now, timeZone, hijriOffsetDays);
  return { greg: g, hijri: h };
}
