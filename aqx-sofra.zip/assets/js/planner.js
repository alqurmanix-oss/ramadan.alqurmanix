/* ============================================================
   تخطيط السفرة: أي خطة (رمضان / شهر) + أي يوم + اختيار الوصفات
   ============================================================ */

import { GREG_MONTHS, daysInGregorianMonth } from './hijri.js';

/** يبني قائمة الخطط: رمضان + 12 شهراً ميلادياً */
export function buildPlans(conf, year) {
  const plans = [];
  const ram = conf.ramadan;
  plans.push({
    id: 'ramadan',
    type: 'hijri',
    name: ram.name,
    emoji: ram.emoji,
    theme: ram.theme,
    days: ram.days || 30,
    slotSet: ram.slotSet,
    seed: ram.seed || 0,
    slots: conf.slotSets[ram.slotSet]
  });

  conf.months.forEach((m, i) => {
    const month = i + 1;
    plans.push({
      id: `m${month}`,
      type: 'greg',
      month,
      name: GREG_MONTHS[i],
      emoji: m.emoji,
      theme: m.theme,
      days: daysInGregorianMonth(year, month),
      slotSet: m.slotSet,
      seed: m.seed != null ? m.seed : month * 5,
      slots: conf.slotSets[m.slotSet]
    });
  });
  return plans;
}

/** أي خطة ويوم ينطبقان على اليوم الحالي */
export function resolveToday(today, plans, ramadanMonth) {
  if (today.hijri && today.hijri.month === ramadanMonth) {
    const plan = plans.find((p) => p.id === 'ramadan');
    return { planId: plan.id, day: Math.min(today.hijri.day, plan.days) };
  }
  return { planId: `m${today.greg.month}`, day: today.greg.day };
}

export function planLabels(plan) {
  return [...new Set(plan.slots.flatMap((s) => s.labels))];
}

/* ---------- اختيار الوصفات ---------- */
function mergePool(slot, pools, exclude) {
  const seen = new Set();
  const out = [];
  for (const label of slot.labels) {
    for (const r of pools[label] || []) {
      if (seen.has(r.url)) continue;
      if (exclude.some((word) => r.title.includes(word))) continue;
      seen.add(r.url);
      out.push(r);
    }
  }
  // الأقدم أولاً: إضافة وصفات جديدة لا تهدم ترتيب الأيام السابقة
  out.sort((a, b) => (a.published < b.published ? -1 : a.published > b.published ? 1 : 0));
  return out;
}

function matchOverride(pool, needle) {
  if (!needle) return null;
  const n = String(needle).trim();
  return pool.find((r) => r.url === n || r.url.endsWith(n) || r.title.includes(n)) || null;
}

/**
 * يبني سفرة اليوم
 * @returns {{plan, day, slots:[{slot, recipe}], heroId}}
 */
export function buildMenu(plan, day, pools, overrides, fallback, exclude = []) {
  const used = new Set();
  const dayIndex = day - 1;
  const planOverrides = (overrides && overrides[plan.id] && overrides[plan.id][String(day)]) || {};
  const items = [];

  plan.slots.forEach((slot, i) => {
    let pool = mergePool(slot, pools, exclude.concat(slot.exclude || []));
    let isFallback = false;
    if (!pool.length && fallback && fallback[slot.id]) {
      pool = fallback[slot.id];
      isFallback = true;
    }

    let recipe = null;
    if (pool.length) {
      recipe = matchOverride(pool, planOverrides[slot.id]);
      if (!recipe) {
        let idx = (dayIndex + plan.seed + i * 3) % pool.length;
        for (let tries = 0; tries < pool.length; tries++) {
          const cand = pool[(idx + tries) % pool.length];
          if (!used.has(cand.url)) { recipe = cand; break; }
        }
        if (!recipe) recipe = pool[idx];
      }
      used.add(recipe.url);
      recipe = { ...recipe, fromFallback: isFallback };
    }
    items.push({ slot, recipe });
  });

  const visible = items.filter((it) => it.recipe || !it.slot.hideIfEmpty);
  const heroId = planOverrides.hero || plan.slots.find((s) => s.hero)?.id || 'main';
  return { plan, day, slots: visible, heroId };
}
