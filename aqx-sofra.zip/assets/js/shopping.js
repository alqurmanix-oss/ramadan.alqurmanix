/* ============================================================
   قائمة التسوق: تجميع مقادير كل أطباق السفرة في قائمة واحدة
   ============================================================ */

const CATEGORIES = [
  { id: 'meat', name: 'لحوم ودواجن وأسماك', icon: '🍗', words: ['دجاج', 'فراخ', 'لحم', 'لحمة', 'مفروم', 'صدور', 'صدر', 'كبد', 'سمك', 'فيليه', 'جمبري', 'ديك', 'ستيك', 'كفتة', 'نقانق', 'بسطرمة'] },
  { id: 'veg', name: 'خضار وفاكهة وأعشاب', icon: '🥬', words: ['بصل', 'ثوم', 'طماطم', 'جزر', 'كرفس', 'ليمون', 'نعناع', 'بقدونس', 'كزبرة', 'خيار', 'خس', 'فلفل', 'باذنجان', 'بطاطس', 'بطاطا', 'كوسة', 'سبانخ', 'ورق عنب', 'تفاح', 'موز', 'برتقال', 'قمر الدين', 'فراولة', 'مانجو', 'رمان', 'جرجير', 'ريحان', 'بامية', 'ملوخية', 'زنجبيل', 'فجل'] },
  { id: 'dairy', name: 'ألبان وبيض وأجبان', icon: '🧀', words: ['لبن', 'حليب', 'زبادي', 'زبدة', 'سمن', 'قشطة', 'كريمة', 'جبن', 'جبنة', 'موزاريلا', 'بيض', 'بيضة', 'قشدة', 'ريكوتا'] },
  { id: 'grain', name: 'أرز وبقوليات ومعجنات', icon: '🌾', words: ['أرز', 'رز', 'عدس', 'حمص', 'فول', 'مكرونة', 'شعيرية', 'دقيق', 'طحين', 'نشا', 'خبز', 'عجين', 'قطايف', 'كنافة', 'فريك', 'برغل', 'سميد', 'شوفان', 'بسكويت', 'رقائق'] },
  { id: 'spice', name: 'توابل وبهارات وصلصات', icon: '🧂', words: ['ملح', 'فلفل أسود', 'كمون', 'كركم', 'قرفة', 'هيل', 'بهارات', 'توابل', 'بابريكا', 'زعتر', 'قرنفل', 'لومي', 'ورق غار', 'معجون', 'صلصة', 'خل', 'صوص', 'ماسالا', 'زعفران', 'ثومية', 'مرق', 'مكعب'] },
  { id: 'oil', name: 'زيوت وسكر وحلويات', icon: '🍯', words: ['زيت', 'سكر', 'عسل', 'شوكولاتة', 'كراميل', 'فانيليا', 'ماء ورد', 'ماء زهر', 'مكسرات', 'لوز', 'فستق', 'جوز', 'عين جمل', 'زبيب', 'جوز هند', 'تمر', 'قطر', 'شربات', 'بكنج', 'خميرة'] }
];

function normalize(text) {
  return String(text)
    .replace(/[ً-ٟـ]/g, '')
    .replace(/[إأآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .replace(/ة/g, 'ه')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function categorize(name) {
  const n = normalize(name);
  for (const cat of CATEGORIES) {
    if (cat.words.some((w) => n.includes(normalize(w)))) return cat.id;
  }
  return 'other';
}

/**
 * @param menu ناتج buildMenu بعد تحميل التفاصيل
 * @returns {{groups:[{id,name,icon,items:[{key,name,amount,from:[]}]}], total:number, missing:[string]}}
 */
export function buildShopping(menu) {
  const map = new Map();
  const missing = [];

  menu.slots.forEach(({ slot, recipe }) => {
    if (!recipe) return;
    const ings = recipe.details && recipe.details.ingredients;
    if (!ings || !ings.length) { missing.push(recipe.title); return; }
    ings.forEach((ing) => {
      const key = normalize(ing.name) + '|' + normalize(ing.amount || '');
      if (!map.has(key)) {
        map.set(key, { key, name: ing.name, amount: ing.amount || '', from: [] });
      }
      const entry = map.get(key);
      if (!entry.from.includes(slot.shortTitle || slot.title)) entry.from.push(slot.shortTitle || slot.title);
    });
  });

  const buckets = {};
  [...CATEGORIES, { id: 'other', name: 'مستلزمات أخرى', icon: '🛍️' }].forEach((c) => {
    buckets[c.id] = { id: c.id, name: c.name, icon: c.icon, items: [] };
  });
  for (const item of map.values()) buckets[categorize(item.name)].items.push(item);

  const groups = Object.values(buckets).filter((g) => g.items.length);
  return { groups, total: map.size, missing };
}

export function shoppingToText(shopping, checked, custom, heading) {
  const lines = [heading, ''];
  shopping.groups.forEach((g) => {
    lines.push(`${g.icon} ${g.name}`);
    g.items.forEach((it) => {
      const mark = checked[it.key] ? '☑' : '☐';
      lines.push(`${mark} ${it.name}${it.amount ? ' — ' + it.amount : ''}`);
    });
    lines.push('');
  });
  if (custom.length) {
    lines.push('✍️ إضافاتي');
    custom.forEach((c) => lines.push(`${checked['c:' + c] ? '☑' : '☐'} ${c}`));
    lines.push('');
  }
  lines.push('— AQX Food | مطبخ القرماني إكس');
  return lines.join('\n');
}
